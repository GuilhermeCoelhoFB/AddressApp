/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.cefetmg.address.view;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author caked
 */
public class PersonViewTest {
    
    public PersonViewTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of menu method, of class PersonView.
     */
    @Test
    public void testMenu() {
        System.out.println("menu");
        PersonView instance = new PersonView();
        instance.menu();
        fail("The test case is a shit.");
    }

    /**
     * Test of insereTxt method, of class PersonView.
     */
    @Test
    public void testInsereTxt() {
        System.out.println("insereTxt");
        PersonView instance = new PersonView();
        instance.insereTxt();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of atualizaTxt method, of class PersonView.
     */
    @Test
    public void testAtualizaTxt() {
        System.out.println("atualizaTxt");
        PersonView instance = new PersonView();
        instance.atualizaTxt();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deletarTxt method, of class PersonView.
     */
    @Test
    public void testDeletarTxt() {
        System.out.println("deletarTxt");
        PersonView instance = new PersonView();
        instance.deletarTxt();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of encontrarTxt method, of class PersonView.
     */
    @Test
    public void testEncontrarTxt() {
        System.out.println("encontrarTxt");
        PersonView instance = new PersonView();
        instance.encontrarTxt();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of listarTxt method, of class PersonView.
     */
    @Test
    public void testListarTxt() {
        System.out.println("listarTxt");
        PersonView instance = new PersonView();
        instance.listarTxt();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
