package br.cefetmg.address.main;

import br.cefetmg.address.view.PersonView;

public class AddressApp {
     
    public static void main(String[] args) {
        PersonView p = new PersonView();
        p.menu();
    }
}